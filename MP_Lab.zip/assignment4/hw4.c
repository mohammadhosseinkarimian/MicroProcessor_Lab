/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : HW4
Version : 
Date    : 3/10/2022
Author  : MohammadHosseinKarimian
Company : 
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/


#include <mega32.h>
#include <delay.h>

//initialized time      
unsigned int firstm = 8;
unsigned int secondm = 5;   
unsigned int firsth   = 3;
unsigned int secondh   = 2; 
unsigned int firsts = 0;
unsigned int seconds = 0;
char dt = 0x80;
unsigned int cntr = 0; 
char number[] = { 0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F }  ;

interrupt [TIM0_COMP] void timer0_comp_isr(void)
{
   cntr++;
    if (cntr == 6) 
        cntr=0;
}

interrupt [TIM1_COMPA] void timer1_compa_isr(void)
{
    dt = 0x00;
    firsts+=1;
    if (firsts%2 == 0)
        dt = 0x80;
            
    if(firsts==10)
    {
        firsts=0;
        seconds+=1;
        if(seconds==6)
        { 
            seconds=0;
            firstm+=1;
            if (firstm==10)
            {
                firstm=0;      
                secondm+=1; 
                if (secondm==6)
                {
                    secondm=0;      
                    firsth+=1;   
                    if (secondh==2 && firsth == 4 )
                    {
                        firsth=0;      
                        secondh=0;
                    }
                    else if (secondh==0 && firsth == 10 )
                    {
                        firsth=0;      
                        secondh+=1;
                    }
                }
            }
       } 
    }
}
// Declare your global variables here
void main(void)
{
PORTA=0x00;
DDRA=0x00;
PORTB=0x00;
DDRB=0x00;
PORTC=0x00;
DDRC=0xFF;
PORTD=0x00;
DDRD=0xFF;
TCCR0=0x0C;
TCNT0=0x00;
OCR0=0x63;
TCCR1A=0x00;
TCCR1B=0x0C;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x7A;
OCR1AL=0x12;
OCR1BH=0x00;
OCR1BL=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;
MCUCR=0x00;
MCUCSR=0x00;
TIMSK=0x12;
ACSR=0x80;
SFIOR=0x00;

#asm("sei")
while (1)
{

    if(cntr == 5){
        PORTD = 0b11011111;
        PORTC = number[firsts] | dt;
    }  
    else if(cntr == 4) {
        PORTD = 0b11101111;
        PORTC = number[seconds];
    }   
    else if(cntr == 3)
    {
        PORTD = 0b11110111;
        PORTC = number[firstm]| dt;
    }  
    else if(cntr == 2) {
        PORTD = 0b11111011;
        PORTC = number[secondm];
    }   
    else if(cntr == 1)
    { 
        PORTD = 0b11111101;
        PORTC = number[firsth]| dt;
    } 
    else if(cntr == 0)
    {
        PORTD = 0b11111110;
        PORTC = number[secondh];
    }
              
}
}
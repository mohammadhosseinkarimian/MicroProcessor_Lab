/*******************************************************
This program was created by the CodeWizardAVR V3.43 
Automatic Program Generator
� Copyright 1998-2021 Pavel Haiduc, HP InfoTech S.R.L.
http://www.hpinfotech.ro

Project : azmayesh 9
Version : 
Date    : 5/2/2021
Author  : mohammad hossein karimian
Company : IUST
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <mega32.h>

// Alphanumeric LCD functions
#include <alcd.h>

// Standard Input/Output functions
#include <stdio.h>

// Declare your global variables here
void usart_send_string(char *str);
unsigned char i;
void main(void)
{
unsigned char charctr, cntr=0;
UCSRA=0x00;
UCSRB=0x18;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x33;
lcd_init(16);
while (1)
      {
        charctr = getchar();
        lcd_putchar(charctr);
        putchar(charctr);
        if(charctr=='C')      
        {
            lcd_clear();   
            putchar(0x0D);  
            putchar(0x0A); 
        } 
         else if(charctr=='M')
        {
            putchar(0x0D);   
            putchar(0x0A);
            lcd_clear();
            lcd_gotoxy(5,0);
            lcd_puts("Mohammad Hossein");
            lcd_gotoxy(0,1);
            lcd_puts("Karimian");          
        } 
       
        else if(charctr=='N')
        {       
            putchar(0x0D); 
            putchar(0x0A); 
            usart_send_string("Mohammad Hossein Karimian");
            putchar(0x0D); 
            putchar(0x0A); 
            
        }
         else if(charctr=='c')
        {
            for(cntr =0; cntr < 24; cntr++)
            {          
                putchar(0x0D);   
                putchar(0x0A);
            }
        }
       
      }        
}

void usart_send_string(char *str)
{
    for(i=0;str[i];i++)
    putchar(str[i]);
}
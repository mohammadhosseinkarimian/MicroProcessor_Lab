/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
ID      :    97521468
Author  :    MohammadHossein Karimian
Company : 
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <mega32.h>
#include <delay.h>

int numb, cntr, pntr;
char array[16] = {1,2,4,8,16,32,64,128, 0, 0, 0, 0, 0, 0, 0, 0};

//this is from matrix coder application
unsigned char letters[]= {
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . . 
    0x7F,    //        . # # # # # # # 
    0x09,    //        . . . . # . . # 
    0x09,    //        . . . . # . . # 
    0x09,    //        . . . . # . . # 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . .
    0x7F,    //        . # # # # # # # 
    0x49,    //        . # . . # . . # 
    0x49,    //        . # . . # . . # 
    0x49,    //        . # . . # . . # 
    0x49,    //        . # . . # . . # 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . .
    0x7F,    //        . # # # # # # # 
    0x41,    //        . # . . . . . # 
    0x41,    //        . # . . . . . # 
    0x41,    //        . # . . . . . # 
    0x3E,    //        . . # # # # # .  
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . . 
    0x3E,    //        . . # # # # # . 
    0x41,    //        . # . . . . . # 
    0x41,    //        . # . . . . . # 
    0x41,    //        . # . . . . . # 
    0x22,    //        . . # . . . # . 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . . 
    0x7F,    //        . # # # # # # # 
    0x49,    //        . # . . # . . # 
    0x49,    //        . # . . # . . # 
    0x49,    //        . # . . # . . # 
    0x36,    //        . . # # . # # . 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . .   
    0x7C,    //        . # # # # # . . 
    0x12,    //        . . . # . . # . 
    0x11,    //        . . . # . . . # 
    0x12,    //        . . . # . . # . 
    0x7C,    //        . # # # # # . . 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . . 
    0x00,    //        . . . . . . . . 
    };


void main(void)
{
// PortB as output 
PORTB=0x00;
DDRB=0xFF;
// PortC as output
PORTC=0x00;
DDRC=0xFF;
// PortD as output 
PORTD=0x00;
DDRD=0xFF;
// cntr/Counter 0 initialization
// Clock source: System Clock
// Clock value: cntr 0 Stopped
// Mode: Normal top=FFh
// OC0 output: Disconnected
TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;
// cntr/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer1 Stopped
// Mode: Normal top=FFFFh
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;
TIMSK=0x00;
    while (1)
    {  
       for(pntr=0;pntr<55;pntr++)
        {
            for(cntr=0;cntr<3;cntr++) 
            {              
                for (numb=0;numb<8;numb++)
                {                             
                PORTD = array[numb];    
                PORTC = ~letters[42-pntr+numb]; 
                delay_ms(1);
                }          
                delay_ms(1);
                for (numb=0;numb<8;numb++)
                {                      
                PORTB = array[numb];      
                PORTC = ~letters[50-pntr+numb]; 
                delay_ms(1);   
                } 
            }
        }
    };
} 